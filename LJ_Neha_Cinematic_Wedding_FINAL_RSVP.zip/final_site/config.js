// Paste your Google Forms responder link between the quotes.
// Example: const RSVP_FORM_URL = 'https://docs.google.com/forms/d/e/XXXXXXXX/viewform';
const RSVP_FORM_URL = 'YOUR_GOOGLE_FORM_LINK_HERE';
